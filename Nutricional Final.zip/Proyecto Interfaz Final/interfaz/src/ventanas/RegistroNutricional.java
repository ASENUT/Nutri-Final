package ventanas;

import java.awt.Image;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class RegistroNutricional extends javax.swing.JFrame {

    public static String cecliente = "";
    public static String fechatratamiento = "";

    public RegistroNutricional() {
        initComponents();
        ImageIcon imagenfondo1 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo2 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo3 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo4 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo5 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo6 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo7 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo8 = new ImageIcon("src/imagenes/574.png");
        ImageIcon imagenfondo9 = new ImageIcon("src/imagenes/574.png");
        Icon icono1 = new ImageIcon(imagenfondo1.getImage().getScaledInstance(jLabel52.getWidth(), jLabel52.getHeight(), Image.SCALE_DEFAULT));
        Icon icono2 = new ImageIcon(imagenfondo2.getImage().getScaledInstance(jLabel43.getWidth(), jLabel43.getHeight(), Image.SCALE_DEFAULT));
        Icon icono3 = new ImageIcon(imagenfondo3.getImage().getScaledInstance(jLabel42.getWidth(), jLabel42.getHeight(), Image.SCALE_DEFAULT));
        Icon icono4 = new ImageIcon(imagenfondo4.getImage().getScaledInstance(jLabel44.getWidth(), jLabel44.getHeight(), Image.SCALE_DEFAULT));
        Icon icono5 = new ImageIcon(imagenfondo5.getImage().getScaledInstance(jLabel499.getWidth(), jLabel499.getHeight(), Image.SCALE_DEFAULT));
        Icon icono6 = new ImageIcon(imagenfondo6.getImage().getScaledInstance(jLabel21.getWidth(), jLabel21.getHeight(), Image.SCALE_DEFAULT));
        Icon icono7 = new ImageIcon(imagenfondo7.getImage().getScaledInstance(jLabel81.getWidth(), jLabel81.getHeight(), Image.SCALE_DEFAULT));
        Icon icono8 = new ImageIcon(imagenfondo8.getImage().getScaledInstance(jLabel48.getWidth(), jLabel48.getHeight(), Image.SCALE_DEFAULT));
        Icon icono9 = new ImageIcon(imagenfondo9.getImage().getScaledInstance(jLabel110.getWidth(), jLabel110.getHeight(), Image.SCALE_DEFAULT));
        jLabel52.setIcon(icono1);
        jLabel43.setIcon(icono2);
        jLabel42.setIcon(icono3);
        jLabel44.setIcon(icono4);
        jLabel499.setIcon(icono5);
        jLabel21.setIcon(icono6);
        jLabel81.setIcon(icono7);
        jLabel48.setIcon(icono8);
        jLabel110.setIcon(icono9);
        this.repaint();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel51 = new javax.swing.JLabel();
        txtCedula = new javax.swing.JTextField();
        txtFechaTrata = new com.toedter.calendar.JDateChooser();
        jLabel12 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        txtOcupacion = new javax.swing.JTextField();
        txtProfesion = new javax.swing.JTextField();
        jLabel74 = new javax.swing.JLabel();
        jLabel75 = new javax.swing.JLabel();
        txtActividad = new javax.swing.JTextField();
        jLabel94 = new javax.swing.JLabel();
        rbtLeve = new javax.swing.JRadioButton();
        rbtModerada = new javax.swing.JRadioButton();
        rbtIntensa = new javax.swing.JRadioButton();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        txtFrecDepor = new javax.swing.JTextField();
        txtTiempoDepor = new javax.swing.JTextField();
        txtTipoDepor = new javax.swing.JTextField();
        jLabel52 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        txtTratamiento = new javax.swing.JTextField();
        jLabel43 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        txtDiagnosticoNutri = new javax.swing.JTextField();
        jLabel42 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        txtDescripcion = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        txtHistoriaAlimenticia = new javax.swing.JTextArea();
        jLabel56 = new javax.swing.JLabel();
        jLabel499 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        txtPesoActual = new javax.swing.JTextField();
        txtPesoHabitual = new javax.swing.JTextField();
        txtPesoIdeal = new javax.swing.JTextField();
        txtTalla = new javax.swing.JTextField();
        txtPesoAumento = new javax.swing.JTextField();
        txtDisminucion = new javax.swing.JTextField();
        txtPMuneca = new javax.swing.JTextField();
        txtContexOsea = new javax.swing.JTextField();
        txtCMB = new javax.swing.JTextField();
        txtIMC = new javax.swing.JTextField();
        txtBiceps = new javax.swing.JTextField();
        txtTriceps = new javax.swing.JTextField();
        txtSubescapular = new javax.swing.JTextField();
        txtSuprailiaco = new javax.swing.JTextField();
        txtCintura = new javax.swing.JTextField();
        txtCadera = new javax.swing.JTextField();
        txtCin_Cad = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        jLabel67 = new javax.swing.JLabel();
        jLabel68 = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        txtAlimentosMayorFrecuencia = new javax.swing.JTextField();
        txtAlimentosMasAgrada = new javax.swing.JTextField();
        txtConsumeAlimentosFueraCasa = new javax.swing.JTextField();
        txtAlergiaAlimenticia = new javax.swing.JTextField();
        txtAlimentosDesagradan = new javax.swing.JTextField();
        txtPersonaPreparaSirveAlimentos = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        txtFaltaApetito = new javax.swing.JTextField();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jLabel81 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel58 = new javax.swing.JLabel();
        cbxBebidasAlcoholicas = new javax.swing.JComboBox<String>();
        jLabel59 = new javax.swing.JLabel();
        cbxConsumeTabaco = new javax.swing.JComboBox<String>();
        jLabel60 = new javax.swing.JLabel();
        cbxAccesoVoracidad = new javax.swing.JComboBox<String>();
        jLabel61 = new javax.swing.JLabel();
        cbxHorasBulimia = new javax.swing.JComboBox<String>();
        jLabel62 = new javax.swing.JLabel();
        cbxAnsiedadNerviosa = new javax.swing.JComboBox<String>();
        jLabel63 = new javax.swing.JLabel();
        cbxComeDeshoras = new javax.swing.JComboBox<String>();
        jLabel64 = new javax.swing.JLabel();
        cbxApetito = new javax.swing.JComboBox<String>();
        jLabel126 = new javax.swing.JLabel();
        txtSuplemetosVitaminicos = new javax.swing.JTextField();
        jLabel127 = new javax.swing.JLabel();
        txtConsumeSalados = new javax.swing.JTextField();
        jLabel128 = new javax.swing.JLabel();
        txtConsumeFrecuenciaFritaras = new javax.swing.JTextField();
        jLabel129 = new javax.swing.JLabel();
        txtFrecuenciaEnlatados = new javax.swing.JTextField();
        jLabel48 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel100 = new javax.swing.JLabel();
        txtConsumeFrecuenciaEmbidos = new javax.swing.JTextField();
        jLabel101 = new javax.swing.JLabel();
        txtComeFrutas = new javax.swing.JTextField();
        jLabel102 = new javax.swing.JLabel();
        txtAlimentosCondimentados = new javax.swing.JTextField();
        jLabel103 = new javax.swing.JLabel();
        txtConsumeGaseosas = new javax.swing.JTextField();
        jLabel104 = new javax.swing.JLabel();
        txtProblemasGastrointentinales = new javax.swing.JTextField();
        jLabel109 = new javax.swing.JLabel();
        txtOtrosProblemasSalud = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtExamenLaboratorio = new javax.swing.JTextArea();
        cbxTipoSangre = new javax.swing.JComboBox<String>();
        jLabel110 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnGuardar = new javax.swing.JMenu();
        btnAtras = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("RegistroCosmetologico"); // NOI18N
        setUndecorated(true);

        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        jTabbedPane1.setTabPlacement(javax.swing.JTabbedPane.LEFT);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel51.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel51.setText("Cedula:");
        jPanel1.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        txtCedula.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCedulaFocusLost(evt);
            }
        });
        jPanel1.add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, 170, 30));
        jPanel1.add(txtFechaTrata, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 10, 150, 30));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel12.setText("Fecha De Ingreso:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 110, 30));

        jLabel57.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel57.setText("Ocupación:");
        jPanel1.add(jLabel57, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 70, 30));
        jPanel1.add(txtOcupacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 60, 150, 30));
        jPanel1.add(txtProfesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 60, 170, 30));

        jLabel74.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel74.setText("Profesión:");
        jPanel1.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 60, 60, 30));

        jLabel75.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel75.setText("Actividad:");
        jPanel1.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 140, -1, 20));
        jPanel1.add(txtActividad, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 130, 170, 30));

        jLabel94.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel94.setText("Actividad Física:");
        jPanel1.add(jLabel94, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, -1, 20));

        rbtLeve.setText("Leve");
        jPanel1.add(rbtLeve, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, -1, 30));

        rbtModerada.setText("Moderada");
        jPanel1.add(rbtModerada, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 170, -1, 30));

        rbtIntensa.setText("Intensa");
        jPanel1.add(rbtIntensa, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 200, -1, 30));

        jLabel76.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel76.setText("Deportes:");
        jPanel1.add(jLabel76, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, -1, -1));

        jLabel77.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel77.setText("Tipo:");
        jPanel1.add(jLabel77, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 300, 40, 30));

        jLabel78.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel78.setText("Tiempo:");
        jPanel1.add(jLabel78, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 60, 30));

        jLabel79.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel79.setText("Frecuencia:");
        jPanel1.add(jLabel79, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, 70, 30));
        jPanel1.add(txtFrecDepor, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 380, 220, 30));
        jPanel1.add(txtTiempoDepor, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 340, 220, 30));
        jPanel1.add(txtTipoDepor, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 300, 220, 30));

        jLabel52.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel52.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jLabel52.setPreferredSize(new java.awt.Dimension(650, 427));
        jPanel1.add(jLabel52, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 630, 450));

        jTabbedPane1.addTab("Actividad Física", jPanel1);

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel5.add(txtTratamiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 510, 350));

        jLabel43.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jLabel43.setToolTipText("");
        jPanel5.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 450));

        jTabbedPane1.addTab("Tratamiento", jPanel5);

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel4.add(txtDiagnosticoNutri, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 510, 350));

        jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel4.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 450));

        jTabbedPane1.addTab("Diagnóstico Nutricional", jPanel4);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel2.add(txtDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, 510, 350));

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel2.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 450));

        jTabbedPane1.addTab("Descripcion", jPanel2);

        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtHistoriaAlimenticia.setColumns(20);
        txtHistoriaAlimenticia.setRows(5);
        jPanel10.add(txtHistoriaAlimenticia, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 520, 330));

        jLabel56.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel56.setText("Descripción de Historia Alimenticia :");
        jPanel10.add(jLabel56, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        jLabel499.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel10.add(jLabel499, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 450));

        jTabbedPane1.addTab("Historia Alimenticia", jPanel10);

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel22.setText("Peso Actual:");
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 20));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel23.setText("Peso Habitual:");
        jPanel3.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, -1, 20));

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel24.setText("Peso Ideal:");
        jPanel3.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 10, -1, 20));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel25.setText("Talla:");
        jPanel3.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, -1, 20));

        jLabel26.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel26.setText("Cambio de Peso:");
        jPanel3.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, 20));

        jLabel27.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel27.setText("Aumento:");
        jPanel3.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 70, -1, 20));

        jLabel28.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel28.setText("Disminución:");
        jPanel3.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 70, -1, 20));

        jLabel29.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel29.setText("Perímetro de la Muñeca:");
        jPanel3.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, 30));

        jLabel30.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel30.setText("Contextura Osea:");
        jPanel3.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, -1, 30));

        jLabel31.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel31.setText("Circunferencia Media del Brazo(CMB):");
        jPanel3.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, -1, 30));

        jLabel32.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel32.setText("Índice de Masa Corporal(IMC):");
        jPanel3.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, -1, 40));

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel33.setText("Pliegues Cutáneos:");
        jPanel3.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, -1, -1));

        jLabel34.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel34.setText("Bíceps:");
        jPanel3.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 260, -1, 20));

        jLabel35.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel35.setText("Triceps:");
        jPanel3.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, -1, 20));

        jLabel36.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel36.setText("Subescapular:");
        jPanel3.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 340, -1, 30));

        jLabel37.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel37.setText("Suprailiaco:");
        jPanel3.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 380, -1, 30));

        jLabel38.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel38.setText("Medidas Corporales:");
        jPanel3.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 260, -1, 20));

        jLabel39.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel39.setText("Cintura");
        jPanel3.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 260, -1, 20));

        jLabel40.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel40.setText("Cadera");
        jPanel3.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 300, -1, 20));

        jLabel41.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel41.setText("Cin/Cad:");
        jPanel3.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 340, -1, 20));
        jPanel3.add(txtPesoActual, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 80, -1));
        jPanel3.add(txtPesoHabitual, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 10, 80, -1));
        jPanel3.add(txtPesoIdeal, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 10, 80, -1));
        jPanel3.add(txtTalla, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 40, 90, -1));
        jPanel3.add(txtPesoAumento, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 70, 70, -1));
        jPanel3.add(txtDisminucion, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 70, 80, -1));
        jPanel3.add(txtPMuneca, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 110, 120, 30));
        jPanel3.add(txtContexOsea, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 150, 100, 30));
        jPanel3.add(txtCMB, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 180, 90, 30));
        jPanel3.add(txtIMC, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 100, 30));
        jPanel3.add(txtBiceps, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, 100, 30));
        jPanel3.add(txtTriceps, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 300, 100, 30));
        jPanel3.add(txtSubescapular, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 340, 100, 30));
        jPanel3.add(txtSuprailiaco, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 380, 100, 30));
        jPanel3.add(txtCintura, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 260, 100, 30));
        jPanel3.add(txtCadera, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 300, 100, 30));
        jPanel3.add(txtCin_Cad, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 340, 100, 30));

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 450));

        jTabbedPane1.addTab("Datos Antropométricos", jPanel3);

        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel65.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel65.setText("Alimentos que consume con mayor frecuencia");
        jPanel7.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel66.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel66.setText("Alimentos que mas le agradan");
        jPanel7.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, -1, 20));

        jLabel67.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel67.setText("Alimentos que le desagradan");
        jPanel7.add(jLabel67, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, -1, 20));

        jLabel68.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel68.setText("Intolerancia y/o alergia alimenticia");
        jPanel7.add(jLabel68, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, 20));

        jLabel69.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel69.setText("Persona que prepara  y sirve  la alimentación");
        jPanel7.add(jLabel69, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, -1, -1));

        jLabel70.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel70.setText("Consume alimentos fuera de casa");
        jPanel7.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, -1, -1));
        jPanel7.add(txtAlimentosMayorFrecuencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 370, 30));
        jPanel7.add(txtAlimentosMasAgrada, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 370, 30));
        jPanel7.add(txtConsumeAlimentosFueraCasa, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 370, 30));
        jPanel7.add(txtAlergiaAlimenticia, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 370, 30));
        jPanel7.add(txtAlimentosDesagradan, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 370, 30));
        jPanel7.add(txtPersonaPreparaSirveAlimentos, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 370, 30));

        jLabel45.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel45.setText("Sufre falta de apetito");
        jPanel7.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, -1, -1));
        jPanel7.add(txtFaltaApetito, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 390, 370, 30));

        jRadioButton1.setText("1v/s");
        jPanel7.add(jRadioButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 340, -1, -1));

        jRadioButton2.setText("2v/s");
        jPanel7.add(jRadioButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 340, -1, -1));

        jRadioButton3.setText("Esporadico");
        jPanel7.add(jRadioButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 340, -1, -1));

        jLabel81.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel7.add(jLabel81, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 450));

        jTabbedPane1.addTab("Historial Diatética Parte I", jPanel7);

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel58.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel58.setText("Bebidas alcohólicas");
        jPanel6.add(jLabel58, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 20));

        cbxBebidasAlcoholicas.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Frecuente", "Esporádico", "Nunca" }));
        jPanel6.add(cbxBebidasAlcoholicas, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, -1, -1));

        jLabel59.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel59.setText("Consume tabaco");
        jPanel6.add(jLabel59, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, -1, 20));

        cbxConsumeTabaco.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Frecuente", "Esporádico", "Nunca" }));
        jPanel6.add(cbxConsumeTabaco, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, -1, -1));

        jLabel60.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel60.setText("Acceso de voracidad");
        jPanel6.add(jLabel60, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, 20));

        cbxAccesoVoracidad.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Si", "No" }));
        jPanel6.add(cbxAccesoVoracidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 90, -1, -1));

        jLabel61.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel61.setText("Horas de bulimia");
        jPanel6.add(jLabel61, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 100, 20));

        cbxHorasBulimia.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        jPanel6.add(cbxHorasBulimia, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, -1, -1));

        jLabel62.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel62.setText("Sufre ansiedad nerviosa");
        jPanel6.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, -1, 20));

        cbxAnsiedadNerviosa.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Si", "No" }));
        jPanel6.add(cbxAnsiedadNerviosa, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 170, -1, -1));

        jLabel63.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel63.setText("Come a deshoras");
        jPanel6.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, -1, 20));

        cbxComeDeshoras.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Si", "No" }));
        jPanel6.add(cbxComeDeshoras, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 220, -1, -1));

        jLabel64.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel64.setText("Apetito");
        jPanel6.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, -1, 20));

        cbxApetito.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Bueno", "Malo", "Exagerado" }));
        jPanel6.add(cbxApetito, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, -1, -1));

        jLabel126.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel126.setText("Suplementos vitamínicos");
        jPanel6.add(jLabel126, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, -1, 20));
        jPanel6.add(txtSuplemetosVitaminicos, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 290, 330, -1));

        jLabel127.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel127.setText("Consume alimentos salados");
        jPanel6.add(jLabel127, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, -1, 20));
        jPanel6.add(txtConsumeSalados, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 320, 330, -1));

        jLabel128.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel128.setText("Consume con frecuencia frituras");
        jPanel6.add(jLabel128, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 350, -1, 20));
        jPanel6.add(txtConsumeFrecuenciaFritaras, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 350, 330, -1));

        jLabel129.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel129.setText("Consume con frecuencia enlatados");
        jPanel6.add(jLabel129, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, -1, 20));
        jPanel6.add(txtFrecuenciaEnlatados, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 380, 330, -1));

        jLabel48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel6.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 450));

        jTabbedPane1.addTab("Historial Diatética Parte II", jPanel6);

        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel100.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel100.setText("Consume con fecuencia embutidos");
        jPanel9.add(jLabel100, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 20));
        jPanel9.add(txtConsumeFrecuenciaEmbidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 370, -1));

        jLabel101.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel101.setText("Consume frutas");
        jPanel9.add(jLabel101, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, 20));
        jPanel9.add(txtComeFrutas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 370, -1));

        jLabel102.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel102.setText("Consume alimentos condimentados");
        jPanel9.add(jLabel102, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, 20));
        jPanel9.add(txtAlimentosCondimentados, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 370, -1));

        jLabel103.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel103.setText("Consume gaseosas");
        jPanel9.add(jLabel103, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, 20));
        jPanel9.add(txtConsumeGaseosas, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 370, -1));

        jLabel104.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel104.setText("Problemas gastrointestinales");
        jPanel9.add(jLabel104, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, -1, 20));
        jPanel9.add(txtProblemasGastrointentinales, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 210, 240, -1));

        jLabel109.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel109.setText("Otros problemas de salud");
        jPanel9.add(jLabel109, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, -1, 20));
        jPanel9.add(txtOtrosProblemasSalud, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 240, 240, -1));

        jLabel53.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel53.setText("Tipo de examen:");
        jPanel9.add(jLabel53, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, -1, 20));

        jLabel54.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel54.setText("Tipo de sangre:");
        jPanel9.add(jLabel54, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, -1, 20));

        txtExamenLaboratorio.setColumns(20);
        txtExamenLaboratorio.setRows(5);
        jScrollPane1.setViewportView(txtExamenLaboratorio);

        jPanel9.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 310, 370, 120));

        cbxTipoSangre.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-" }));
        jPanel9.add(cbxTipoSangre, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 280, -1, -1));

        jLabel110.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jPanel9.add(jLabel110, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 640, 450));

        jTabbedPane1.addTab("Historial Diatética Parte III", jPanel9);

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Save.png"))); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnGuardarMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnGuardar);

        btnAtras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        btnAtras.setText("Regresar");
        btnAtras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAtrasMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnAtras);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 791, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 457, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTabbedPane1.getAccessibleContext().setAccessibleName("tab3");

        getAccessibleContext().setAccessibleName("Registro");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAtrasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAtrasMouseClicked
        // TODO add your handling code here:
        DatosGenerales dg = new DatosGenerales();
        dg.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnAtrasMouseClicked

    private void btnGuardarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGuardarMouseClicked
        //Guardar
        PreparedStatement cmd;
        ResultSet rs;
        Conexion.Conectar();
        int cont = 0;
        String variable;
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////TRATAMIENTO////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String tratamiento = txtTratamiento.getText().toUpperCase();
        int conttrata = 0;
        String codptrata = null;
        //SELECT * FROM TIPO_TRATAMIENTO
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_TRATAMIENTO FROM TIPO_TRATAMIENTO WHERE NOM_TRATA = '" + tratamiento + "'");
            while (rs.next()) {
                conttrata++;
                codptrata = rs.getString(1);
            }
            if (conttrata == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO TIPO_TRATAMIENTO (COD_TRATA_FACIAL, NOM_TRATA) VALUES ('1', '" + tratamiento + "')");
                    cmd.execute();
                    rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_TRATAMIENTO FROM TIPO_TRATAMIENTO WHERE NOM_TRATA = '" + tratamiento + "'");
                    while (rs.next()) {
                        codptrata = rs.getString(1);
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, e + "\nTIPO TRATAMIENTO");
                }
            }
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_TRATAMIENTO FROM TIPO_TRATAMIENTO WHERE NOM_TRATA = '" + tratamiento + "'");
            conttrata = 0;
            while (rs.next()) {
                codptrata = rs.getString(1);
                conttrata++;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNo se ingresó en TipoTratamiento");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////PACIENTE TRATA//////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String fdia = "";
        String fmes = "";
        if (txtFechaTrata.getCalendar().get(Calendar.DAY_OF_MONTH) <= 9) {
            fdia = "0" + txtFechaTrata.getCalendar().get(Calendar.DAY_OF_MONTH);
        } else {
            fdia = String.valueOf(txtFechaTrata.getCalendar().get(Calendar.DAY_OF_MONTH));
        }

        if ((txtFechaTrata.getCalendar().get(Calendar.MONTH) + 1) <= 9) {
            fmes = "0" + ((txtFechaTrata.getCalendar().get(Calendar.MONTH) + 1));
        } else {
            fmes = String.valueOf((txtFechaTrata.getCalendar().get(Calendar.MONTH) + 1));
        }
        String cedula = "'" + txtCedula.getText() + "'";
        String fechatrata = "'" + txtFechaTrata.getCalendar().get(Calendar.YEAR) + "-" + fmes + "-" + fdia + "'";
        String cedemple = Interfaz.ci;

        System.out.println("fecha: " + fechatrata + "ceduemple: " + cedemple);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////ACTIVIDAD FÍSICA//////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String ocup = txtOcupacion.getText().toUpperCase();
        int contocup = 0;
        String codocup = "";
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select COD_OCUP from OCUPACION where NOM_OCUP = '" + ocup + "'");
            while (rs.next()) {
                codocup = rs.getString(1);
                contocup++;
            }
            if (contocup == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("insert into OCUPACION (NOM_OCUP) VALUES ('" + ocup + "')");
                    cmd.execute();
                    rs = ventanas.Conexion.link.createStatement().executeQuery("select COD_OCUP from OCUPACION where NOM_OCUP = '" + ocup + "'");
                    while (rs.next()) {
                        codocup = rs.getString(1);
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "NO SE INGRESO OCUPACION");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ES EN OCUPACION");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        int contprof = 0;
        String codprof = "";
        String prof = txtProfesion.getText().toUpperCase();
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select COD_PROFESION from PROFESION where NOM_PROFESION = '" + prof + "'");
            while (rs.next()) {
                codprof = rs.getString(1);
                contprof++;
            }
            if (contprof == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("insert into PROFESION (NOM_PROFESION) VALUES ('" + prof + "')");
                    cmd.execute();
                    rs = ventanas.Conexion.link.createStatement().executeQuery("select COD_PROFESION from PROFESION where NOM_PROFESION = '" + prof + "'");
                    while (rs.next()) {
                        codprof = rs.getString(1);
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "NO SE INGRESO PROFESION");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ES EN PROFESION");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String codnivel = "";
        if (rbtLeve.isSelected() == true) {
            codnivel = "1";
        } else if (rbtModerada.isSelected() == true) {
            codnivel = "2";
        } else if (rbtIntensa.isSelected() == true) {
            codnivel = "3";
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String tipodepor = txtTipoDepor.getText().toUpperCase();
        String tiempodepor = txtTiempoDepor.getText();
        String fdepor = txtFrecDepor.getText().toUpperCase();
        String coddepor = "";
        //SELECT D.COD_DEPORTE FROM DEPORTES D WHERE D.TIPO_DEPORTE = 'FUTBOL' AND D.TIEMPO_DEPORTE = '01:00' AND D.FRECUENCIA = 'INTENSA';
        int contdepor = 0;
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT D.COD_DEPORTE FROM DEPORTES D WHERE D.TIPO_DEPORTE = '" + tipodepor + "' AND D.TIEMPO_DEPORTE = '" + tiempodepor + "' AND D.FRECUENCIA = '" + fdepor + "'");
            while (rs.next()) {
                coddepor = rs.getString(1);
                contdepor++;
            }
            if (contdepor == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO DEPORTES (TIPO_DEPORTE, TIEMPO_DEPORTE, FRECUENCIA) VALUES ('" + tipodepor + "', '" + tiempodepor + "', '" + fdepor + "')");
                    cmd.execute();
                    rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT D.COD_DEPORTE FROM DEPORTES D WHERE D.TIPO_DEPORTE = '" + tipodepor + "' AND D.TIEMPO_DEPORTE = '" + tiempodepor + "' AND D.FRECUENCIA = '" + fdepor + "'");
                    while (rs.next()) {
                        coddepor = rs.getString(1);
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "NO DEPORTE");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ES DEPORTE");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String codact = "";
        String acti = txtActividad.getText().toUpperCase();
        int contacti = 0;
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select COD_ACT from ACTIVIDAD where NOM_ACT = '" + acti + "'");
            while (rs.next()) {
                codact = rs.getString(1);
                contacti++;
            }
            if (contacti == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("insert into ACTIVIDAD (NOM_ACT) VALUES ('" + acti + "')");
                    cmd.execute();
                    rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_ACT FROM ACTIVIDAD WHERE NOM_ACT = '" + acti + "'");
                    while (rs.next()) {
                        codact = rs.getString(1);
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "NO SE INGRESO ACTIVIDAD");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ES EN ACTIVIDAD");
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////ACTIVIDAD FÍSICA/////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select * from ACTIVIDAD_FISICA");
            while (rs.next()) {
                contocup++;
            }
            cmd = ventanas.Conexion.link.prepareStatement("insert into ACTIVIDAD_FISICA "
                    + "(COD_NIV, COD_OCUP, COD_PROFESION, COD_DEPORTE, COD_ACT, FECHA_TRATA, CEDULA, COD_TRATAMIENTO)"
                    + " VALUES ('" + codnivel + "', '" + codocup + "', '" + codprof + "', '" + coddepor
                    + "', '" + codact + "', " + fechatrata + ", " + cedula + ", '" + codptrata + "')");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNO SE INGRESO ACTIVIDAD_FISICA");
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////DIAGNOSTICO////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String diagnostico = txtDiagnosticoNutri.getText().toUpperCase();
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO DIAGNOSTICO (DESC_DIAGNOSTICO) VALUES ('" + diagnostico + "')");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\n\tNo se ingreso Diagnostico");
        }
        String descripcion = txtDiagnosticoNutri.getText().toUpperCase();
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO DESCRIPCION (DESCRIPCION) VALUES ('" + descripcion + "')");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\n\tNo se ingreso Descripcion");
        }

        //////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////HISTORIA CLINICA (OJO)//////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////
        String codhisto = "";

        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_HISTORIA "
                    + "FROM HISTORIA_CLINICA WHERE CEDULA = " + cedula);
            while (rs.next()) {
                cont++;
            }
            if (cont == 0) {
                rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT * FROM HISTORIA_CLINICA");
                while (rs.next()) {
                    cont++;
                }
                cont += 1;
                codhisto = String.valueOf(cont);
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO HISTORIA_CLINICA "
                            + "(COD_HISTORIA, FECHA_TRATA, CEDULA, COD_TRATAMIENTO) "
                            + "VALUES ('" + codhisto + "', " + fechatrata
                            + ", " + cedula + ", '" + codptrata + "')");
                    cmd.execute();
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, e + "\nNo se ingreso HISTORIA CLINICA");
                }
            } else {
                rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT HC.COD_HISTORIA FROM HISTORIA_CLINICA HC WHERE HC.CEDULA = " + cedula);
                while (rs.next()) {
                    codhisto = rs.getString(1);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nES OTRO PRO DE HC");
        }
        cont = 0;
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////DATOS DIETETICOS////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        //0 Falso
        //1 Verdadero
        String codhistodiet = "";
        //String codcondualifuecasa = "";//Está abajo
        String codbebidas = "";//cbx-
        String codcontabaco = "";//cbx-
        String codapetito = "";//cbx-
        String codproblema = "";
        String codsangre = "";//cbx-
        String codotroproblemas = "";
        String alimafrec = txtAlimentosMayorFrecuencia.getText().toUpperCase();
        String alimasagrada = txtAlimentosMasAgrada.getText().toUpperCase();
        String alidesagradan = txtAlimentosDesagradan.getText().toUpperCase();
        String alergia = txtAlergiaAlimenticia.getText().toUpperCase();
        String persirali = txtPersonaPreparaSirveAlimentos.getText().toUpperCase();
        String consalifuera = txtConsumeAlimentosFueraCasa.getText().toUpperCase();
        String voracidad = "";//cbx
        String horbulimia = "0";//cbx
        String sufreansiedad = "";//cbx
        String sufrefalta = txtFaltaApetito.getText().toUpperCase();
        String comedeshora = "";//cbx
        String suplevita = txtSuplemetosVitaminicos.getText().toUpperCase();
        String consualisal = txtConsumeSalados.getText().toUpperCase();
        String consufrecfri = txtConsumeFrecuenciaFritaras.getText().toUpperCase();
        String consufreclata = txtFrecuenciaEnlatados.getText().toUpperCase();
        String consufrecembu = txtConsumeFrecuenciaEmbidos.getText().toUpperCase();
        String consufruta = txtComeFrutas.getText().toUpperCase();
        String consualicondi = txtAlimentosCondimentados.getText().toUpperCase();
        String consugaseosa = txtConsumeGaseosas.getText().toUpperCase();

        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxBebidasAlcoholicas.getSelectedItem();
        if ("Frecuente".equals(variable)) {
            codbebidas = "1";
        }
        if ("Esporádico".equals(variable)) {
            codbebidas = "2";
        }
        if ("Frecuente".equals(variable)) {
            codbebidas = "3";
        }
        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxConsumeTabaco.getSelectedItem();
        if ("Frecuente".equals(variable)) {
            codcontabaco = "1";
        }
        if ("Esporádico".equals(variable)) {
            codcontabaco = "2";
        }
        if ("Nunca".equals(variable)) {
            codcontabaco = "3";
        }
        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxApetito.getSelectedItem();
        if ("Bueno".equals(variable)) {
            codapetito = "1";
        }
        if ("Malo".equals(variable)) {
            codapetito = "2";
        }
        if ("Exagerado".equals(variable)) {
            codapetito = "3";
        }
        //////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxAccesoVoracidad.getSelectedItem();
        if ("Si".equals(variable)) {
            voracidad = "1";
        }
        if ("No".equals(variable)) {
            voracidad = "0";
        }
        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxHorasBulimia.getSelectedItem();
        if ("1".equals(variable)) {
            horbulimia = "1";
        }
        if ("2".equals(variable)) {
            horbulimia = "2";
        }
        if ("3".equals(variable)) {
            horbulimia = "3";
        }
        if ("4".equals(variable)) {
            horbulimia = "4";
        }
        if ("5".equals(variable)) {
            horbulimia = "5";
        }
        if ("6".equals(variable)) {
            horbulimia = "6";
        }
        if ("7".equals(variable)) {
            horbulimia = "7";
        }
        if ("8".equals(variable)) {
            horbulimia = "8";
        }
        if ("9".equals(variable)) {
            horbulimia = "9";
        }
        if ("10".equals(variable)) {
            horbulimia = "10";
        }
        if ("11".equals(variable)) {
            horbulimia = "11";
        }
        if ("12".equals(variable)) {
            horbulimia = "12";
        }
        if ("0".equals(variable)) {
            horbulimia = "0";
        }
        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxAnsiedadNerviosa.getSelectedItem();
        if ("Si".equals(variable)) {
            sufreansiedad = "Si";
        }
        if ("No".equals(variable)) {
            sufreansiedad = "No";
        }
        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxComeDeshoras.getSelectedItem();
        if ("Si".equals(variable)) {
            comedeshora = "Si";
        }
        if ("No".equals(variable)) {
            comedeshora = "No";
        }
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        String consuefueca = "";
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_PROBLEMA FROM PROBLEMAS_GASTROINTESTINALES WHERE NOM_PROBLEMA = '" + txtProblemasGastrointentinales.getText().toUpperCase() + "'");
            while (rs.next()) {
                cont++;
            }
            if (cont == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO PROBLEMAS_GASTROINTESTINALES (NOM_PROBLEMA) VALUES ('" + txtProblemasGastrointentinales.getText().toUpperCase() + "')");
                    cmd.execute();//INGRESO A PROBLIMAS GASTROINTESTINALES
                    rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_PROBLEMA FROM PROBLEMAS_GASTROINTESTINALES WHERE NOM_PROBLEMA = '" + txtProblemasGastrointentinales.getText().toUpperCase() + "'");
                    while (rs.next()) {
                        codproblema = rs.getString(1);
                    }
                    cont = 0;
                    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                    rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_CONSU_ALI_FUE_CA FROM CONSUME_ALIMENTOS_FUERA_DE_CASA WHERE DES_CON_ALI = '" + txtConsumeAlimentosFueraCasa.getText().toUpperCase() + "'");
                    while (rs.next()) {
                        cont++;
                        consuefueca = rs.getString(1);
                    }
                    if (cont == 0) {
                        cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO CONSUME_ALIMENTOS_FUERA_DE_CASA (DES_CON_ALI) VALUES ('" + txtConsumeAlimentosFueraCasa.getText().toUpperCase() + "')");
                        cmd.execute();
                        rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_CONSU_ALI_FUE_CA FROM CONSUME_ALIMENTOS_FUERA_DE_CASA WHERE DES_CON_ALI = '" + txtConsumeAlimentosFueraCasa.getText().toUpperCase() + "'");
                        while (rs.next()) {
                            consuefueca = rs.getString(1);
                        }
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, e + "\nNo se ingreso Consume Alimentos Fuera de Casa y Problemas gastro");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "Fuera de casa y Gatrointestinales");
        }
        cont = 0;
        System.out.println(consuefueca + "    assdfg");
        //////////////////////////////////////////////////////////////////////////////////////
        variable = (String) cbxTipoSangre.getSelectedItem();
        if ("A+".equals(variable)) {
            codsangre = "1";
        }
        if ("A-".equals(variable)) {
            codsangre = "2";
        }
        if ("B+".equals(variable)) {
            codsangre = "3";
        }
        if ("B-".equals(variable)) {
            codsangre = "4";
        }
        if ("AB+".equals(variable)) {
            codsangre = "5";
        }
        if ("AB-".equals(variable)) {
            codsangre = "6";
        }
        if ("O+".equals(variable)) {
            codsangre = "7";
        }
        if ("O-".equals(variable)) {
            codsangre = "8";
        }
        //////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////////////////////////////////
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_OTRO FROM OTROS_PROBLEMAS WHERE NOMBRE_OTRO_PROBLEMA = '" + txtOtrosProblemasSalud.getText().toUpperCase() + "'");
            while (rs.next()) {
                cont++;
            }
            if (cont == 0) {
                try {
                    cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO OTROS_PROBLEMAS (NOMBRE_OTRO_PROBLEMA) VALUES ('" + txtOtrosProblemasSalud.getText().toUpperCase() + "')");
                    cmd.execute();
                    rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_OTRO FROM OTROS_PROBLEMAS WHERE NOMBRE_OTRO_PROBLEMA = '" + txtOtrosProblemasSalud.getText().toUpperCase() + "'");
                    while (rs.next()) {
                        codotroproblemas = rs.getString(1);
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, e + "\nNo se ingreso Otros Problemas");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        cont = 0;
        //////////////////////////////////////////////////////////////////////////////////////
        String exam = txtExamenLaboratorio.getText();
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_HISTORIA_DIETETICA FROM HISTORIA_DIETETICA");
            while (rs.next()) {
                cont++;
            }
            cont = +1;
            codhistodiet = String.valueOf(cont);
            try {
                cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO HISTORIA_DIETETICA "
                        + "VALUES ('" + codhistodiet + "', '" + consuefueca + "', '" + codbebidas + "', '" + codcontabaco
                        + "', '" + codapetito + "', '" + codproblema + "', '" + codotroproblemas
                        + "', '" + codhisto + "',  " + fechatrata + " , '" + alimafrec + "', '" + alimasagrada
                        + "', '" + alidesagradan + "', '" + alergia + "', '" + persirali + "', '" + consalifuera
                        + "', '" + voracidad + "', '" + horbulimia + "', '" + sufreansiedad + "', '" + sufrefalta
                        + "', '" + comedeshora + "', '" + suplevita + "', '" + consualisal + "', '" + consufrecfri
                        + "', '" + consufreclata + "', '" + consufrecembu + "', '" + consufruta + "', '" + consualicondi
                        + "', '" + consugaseosa + "', '" + exam + "')");
                cmd.execute();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, e + "\nNO Datos Dieteticos");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nES Datos Dieteticos");
        }
        cont = 0;

        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////DATOS ANTROPOMETRICOS///////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String codantro = "";
        String pesoactual = txtPesoActual.getText();
        String pesohabitual = txtPesoHabitual.getText();
        String pesoideal = txtPesoIdeal.getText();
        String talla = txtTalla.getText();
        String pesoaumento = txtPesoAumento.getText();
        String pesodisminucion = txtDisminucion.getText();
        String permuneca = txtPMuneca.getText();
        String contexosea = txtContexOsea.getText();
        String cmb = txtCMB.getText();
        String imc = txtIMC.getText();
        String biceps = txtBiceps.getText();
        String triceps = txtTriceps.getText();
        String subescapular = txtSubescapular.getText();
        String suprailiaco = txtSuprailiaco.getText();
        String cintura = txtCintura.getText();
        String cadera = txtCadera.getText();
        String cin_cad = txtCin_Cad.getText();
        int contdatant = 0;
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_ANTROPOMETRICO FROM DATOS_ANTROPOMETRICOS");
            while (rs.next()) {
                contdatant++;
            }
            codantro = String.valueOf(contdatant + 1);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e + "\nNo se hizo la consulta de DA");
        }
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO DATOS_ANTROPOMETRICOS VALUES ('" + codantro + "', '" + pesoactual
                    + "', '" + pesohabitual + "', '" + pesoideal + "', '" + talla + "', '" + pesoaumento + "', '" + pesodisminucion
                    + "', '" + permuneca + "', '" + contexosea + "', '" + cmb + "', '" + imc + "', '" + biceps + "', '" + triceps
                    + "', '" + subescapular + "', '" + suprailiaco + "', '" + cintura + "', '" + cadera + "', '" + cin_cad + "')");

            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNO Datos Antropometricos");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        String coddiag = "";
        String coddesc = "";
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_DIAGNOSTICO FROM DIAGNOSTICO WHERE DESC_DIAGNOSTICO = '" + txtDiagnosticoNutri.getText().toUpperCase() + "'");
            while (rs.next()) {
                coddiag = rs.getString(1);
            }
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_DESCRIPCION FROM DESCRIPCION DC WHERE DC.DESCRIPCION = '" + txtDescripcion.getText().toUpperCase() + "'");
            while (rs.next()) {
                coddesc = rs.getString(1);
            }
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO OBTIENE VALUES "
                    + "(" + codhisto + ", " + coddiag + ", '1', " + fechatrata + ")");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNo se ingresó en Obtiene");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        cont = 0;
        String codhistoali = "";
        String deschistoali = txtHistoriaAlimenticia.getText();

        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_HISTO_ALIMENTICIA FROM HISTORIA_ALIMENTICIA");
            while (rs.next()) {
                cont++;
            }
            cont += 1;
            codhistoali = String.valueOf(cont);
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO HISTORIA_ALIMENTICIA VALUES "
                    + "('" + codhistoali + "', '" + deschistoali + "')");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNo ingrsó en histo alimenticia");
        }
        cont = 0;
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO REALIZADO VALUES "
                    + "('" + codhistoali + "', '1', '" + codhisto + "', " + fechatrata + ")");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNo ingreso en realizado");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO POSEE VALUES "
                    + "('" + codantro + "', " + fechatrata + ", " + cedula + ", '" + codptrata + "', '" + fechatrata + ")");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "NO POSEE\n" + e);
        }///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO OBTIENE VALUES "
                    + "('" + codhisto + "', '" + coddiag + "', '" + coddesc + "', " + fechatrata + ")");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "NO OBTIENE\n" + e);
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////
        try {
            cmd = ventanas.Conexion.link.prepareStatement("INSERT INTO PACIENTE_TRATAMIENTO "
                    + "(FECHA_TRATA, CEDULA, COD_TRATAMIENTO, CED_EMPLEADO) "
                    + "VALUES (" + fechatrata + ", " + cedula + ", '" + codptrata + "', '" + cedemple + "')");
            cmd.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e + "\nNo se ingreso Paciente Trata");
        }
        System.out.println("Fin ingreso");
//INSERT INTO PACIENTE_TRATAMIENTO (FECHA_TRATA, CEDULA, COD_TRATAMIENTO, CED_EMPLEADO) VALUES ('2016-12-12', '0802502948', '1', '1020304050');

    }//GEN-LAST:event_btnGuardarMouseClicked

    private void txtCedulaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCedulaFocusLost
        // COMPROBAMOS QUE EL PACIENTE EXISTA
        ResultSet rs;
        RegistroCliente rc = new RegistroCliente();
        String cedula = "'" + txtCedula.getText() + "'";
        int count = 0;

        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select CEDULA from PACIENTE where CEDULA = " + cedula);
            while (rs.next()) {
                count++;
            }
            if (count == 0) {
                JOptionPane.showMessageDialog(null, "El cliente no está registrado.\nPor favor registrelo primero");
                //rc.show();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        cecliente = txtCedula.getText();
    }//GEN-LAST:event_txtCedulaFocusLost

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroNutricional().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu btnAtras;
    private javax.swing.JMenu btnGuardar;
    private javax.swing.JComboBox<String> cbxAccesoVoracidad;
    private javax.swing.JComboBox<String> cbxAnsiedadNerviosa;
    private javax.swing.JComboBox<String> cbxApetito;
    private javax.swing.JComboBox<String> cbxBebidasAlcoholicas;
    private javax.swing.JComboBox<String> cbxComeDeshoras;
    private javax.swing.JComboBox<String> cbxConsumeTabaco;
    private javax.swing.JComboBox<String> cbxHorasBulimia;
    private javax.swing.JComboBox<String> cbxTipoSangre;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel499;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JRadioButton rbtIntensa;
    private javax.swing.JRadioButton rbtLeve;
    private javax.swing.JRadioButton rbtModerada;
    private javax.swing.JTextField txtActividad;
    private javax.swing.JTextField txtAlergiaAlimenticia;
    private javax.swing.JTextField txtAlimentosCondimentados;
    private javax.swing.JTextField txtAlimentosDesagradan;
    private javax.swing.JTextField txtAlimentosMasAgrada;
    private javax.swing.JTextField txtAlimentosMayorFrecuencia;
    private javax.swing.JTextField txtBiceps;
    private javax.swing.JTextField txtCMB;
    private javax.swing.JTextField txtCadera;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtCin_Cad;
    private javax.swing.JTextField txtCintura;
    private javax.swing.JTextField txtComeFrutas;
    private javax.swing.JTextField txtConsumeAlimentosFueraCasa;
    private javax.swing.JTextField txtConsumeFrecuenciaEmbidos;
    private javax.swing.JTextField txtConsumeFrecuenciaFritaras;
    private javax.swing.JTextField txtConsumeGaseosas;
    private javax.swing.JTextField txtConsumeSalados;
    private javax.swing.JTextField txtContexOsea;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtDiagnosticoNutri;
    private javax.swing.JTextField txtDisminucion;
    private javax.swing.JTextArea txtExamenLaboratorio;
    private javax.swing.JTextField txtFaltaApetito;
    private com.toedter.calendar.JDateChooser txtFechaTrata;
    private javax.swing.JTextField txtFrecDepor;
    private javax.swing.JTextField txtFrecuenciaEnlatados;
    private javax.swing.JTextArea txtHistoriaAlimenticia;
    private javax.swing.JTextField txtIMC;
    private javax.swing.JTextField txtOcupacion;
    private javax.swing.JTextField txtOtrosProblemasSalud;
    private javax.swing.JTextField txtPMuneca;
    private javax.swing.JTextField txtPersonaPreparaSirveAlimentos;
    private javax.swing.JTextField txtPesoActual;
    private javax.swing.JTextField txtPesoAumento;
    private javax.swing.JTextField txtPesoHabitual;
    private javax.swing.JTextField txtPesoIdeal;
    private javax.swing.JTextField txtProblemasGastrointentinales;
    private javax.swing.JTextField txtProfesion;
    private javax.swing.JTextField txtSubescapular;
    private javax.swing.JTextField txtSuplemetosVitaminicos;
    private javax.swing.JTextField txtSuprailiaco;
    private javax.swing.JTextField txtTalla;
    private javax.swing.JTextField txtTiempoDepor;
    private javax.swing.JTextField txtTipoDepor;
    private javax.swing.JTextField txtTratamiento;
    private javax.swing.JTextField txtTriceps;
    // End of variables declaration//GEN-END:variables
}
