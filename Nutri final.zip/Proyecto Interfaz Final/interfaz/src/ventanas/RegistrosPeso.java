package ventanas;

import java.awt.Graphics;
import java.awt.PrintJob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class RegistrosPeso extends javax.swing.JFrame {

    public RegistrosPeso() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        txtCedula = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cbxTratamientos = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        btnImprimir = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Sesion", "Fecha", "Peso", "Tratamineto", "Atendido por:", "Observaciones"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 726, 275));

        txtCedula.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCedulaFocusLost(evt);
            }
        });
        getContentPane().add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, 100, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setText("CI :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setText("Medidas de:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("Fecha:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setText("Tratamiento:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 20, -1, -1));

        cbxTratamientos.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbxTratamientos.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbxTratamientosItemStateChanged(evt);
            }
        });
        getContentPane().add(cbxTratamientos, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 20, -1, -1));
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 80, 20));
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 80, 90, 20));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        jLabel4.setName("ficha"); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 410));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnImprimir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Imprimir.png"))); // NOI18N
        btnImprimir.setText("Imprimir");
        btnImprimir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnImprimirMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnImprimir);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        jMenu2.setText("Regresar");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnImprimirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnImprimirMouseClicked
         // TODO add your handling code here:
        PrintJob imprime = getToolkit().getPrintJob(this, evt.getClass().getName(), null);
        if (imprime != null) {
            Graphics pag = imprime.getGraphics();
            if (pag != null) {
                paint(pag); //pinta todo los objetos de la ventana mostrada
                pag.dispose();
            }
        } else {
            //JOptionPane.showMessageDialog(null, “no se imprimo nada”, “imprimir”, JOptionPane.INFORMATION_MESSAGE );
            imprime.end();
        }
        imprime.end();
    }//GEN-LAST:event_btnImprimirMouseClicked

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        // TODO add your handling code here:
        TratamientoNutricional dg = new TratamientoNutricional();
        dg.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenu2MouseClicked

    private void txtCedulaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCedulaFocusLost
        // TODO add your handling code here:
        ResultSet rs;
        String nombre = "";
        String ced = "";

        cargarlista();

        ced = txtCedula.getText();
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select concat(APE_PAC, ' ', NOM_PAC) from PACIENTE WHERE CEDULA = '" + ced + "'");
            while (rs.next()) {
                nombre = rs.getString(1);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos del paciente");
        }

        jLabel6.setText(nombre);
        System.out.println(ced);
    }//GEN-LAST:event_txtCedulaFocusLost

    private void cbxTratamientosItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbxTratamientosItemStateChanged
        // TODO add your handling code here:
        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        
//        String ced = txtCedula.getText();
        String nomtrata = "";
        String codptrata = "";//OJO HACER CONSULTA DEL TRATAMIENTO
        nomtrata = (String) cbxTratamientos.getSelectedItem();
        System.out.println(nomtrata);
        int cont = 0;
///////////////////////////////////////////////////////////////
        String nombre = "";
        String ced = HistorialNutricional.cedulantri;
        cargarlista();
        
        txtCedula.setText(ced);
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("select concat(APE_PAC, ' ', NOM_PAC) from PACIENTE WHERE CEDULA = '" + ced + "'");
            while (rs.next()) {
                nombre = rs.getString(1);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos del paciente");
        }

        jLabel6.setText(nombre);
        System.out.println(ced);
        ///////////////////////////////////////////////////////////////////////////
        
        try {
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT COD_TRATAMIENTO FROM TIPO_TRATAMIENTO WHERE NOM_TRATA = '" + nomtrata + "'");
            while (rs.next()) {
                codptrata = rs.getString(1);
            }
            System.out.println(codptrata);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se encotró el tratamiento");
        }

        try {
            dtm.addColumn("Sesion");
            dtm.addColumn("Fecha");
            dtm.addColumn("Peso");
            dtm.addColumn("Tratamiento");
            dtm.addColumn("Observaciones");
            dtm.addColumn("Atendido por:");
            /*
             MD.FECHA_MEDICION, TT.NOM_TRATA, MD.BUSTO, 
             MD.CADERAS, MD.CINTURA, MD.ENTREPIERNA_DER, 
             MD.ENTREPIERNA_IZ, MD.ESTOMAGO, MD.MUSLO_DER, MD.MUSLO_IZ*/
            rs = ventanas.Conexion.link.createStatement().executeQuery("select distinct PP.FECHA_TRATA, PP.PESO_PACIENTE, PP.TRATAMIENTO, PP.OBSERVACIONES, U.NOM_USUARIO\n" +
"from PESO_PACIENTE PP, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT, USUARIO U\n" +
"where  PP.CEDULA = PT.CEDULA AND PP.COD_TRATAMIENTO = TT.COD_TRATAMIENTO \n" +
"AND U.CED_EMPLEADO = PT.CED_EMPLEADO AND PP.CEDULA = '" + ced + "' AND PP.COD_TRATAMIENTO = '" + codptrata + "'");
            while (rs.next()) {
                cont++;
                dtm.addRow(new Object[]{cont ,rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)});
            }
            jTable1.setModel(dtm);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_cbxTratamientosItemStateChanged

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        cbxTratamientos.removeAllItems();
        Calendar calen = new GregorianCalendar();
        int dia, mes, anio;
        anio = calen.get(Calendar.YEAR);
        mes = calen.get(Calendar.MONTH) + 1;
        dia = calen.get(Calendar.DAY_OF_MONTH);
        String fecha = anio + "-" + mes + "-" + dia;
        jLabel7.setText(fecha);
    }//GEN-LAST:event_formWindowActivated

    private void cargarlista() {
        // TODO Auto-generated method stub
        ResultSet rs;
        //cbxTratamientos.addItem("Seleccione");
        try {
            Conexion.Conectar();
            rs = ventanas.Conexion.link.createStatement().executeQuery("select TT.NOM_TRATA from PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT WHERE PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CEDULA = '" + txtCedula.getText() + "';");
            while (rs.next()) {
                String tmpStrObtenido = rs.getString(1);
                cbxTratamientos.addItem(tmpStrObtenido);
            }
            Conexion.Close();
            Conexion.Conectar();
        } catch (Exception e) {
            System.out.println("ERROR: falla al cargar los trataminetos");
        }

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistrosPeso.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistrosPeso.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistrosPeso.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistrosPeso.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistrosPeso().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu btnImprimir;
    private javax.swing.JComboBox cbxTratamientos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtCedula;
    // End of variables declaration//GEN-END:variables
}
