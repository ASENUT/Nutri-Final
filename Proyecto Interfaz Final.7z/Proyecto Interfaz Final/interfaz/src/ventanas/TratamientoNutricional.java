package ventanas;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TratamientoNutricional extends javax.swing.JFrame {

    static String cedulaFicha = "";
    
    public TratamientoNutricional() {
        initComponents();
        this.setLocationRelativeTo(null);
    }
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnBusqueda = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox();
        txtBusqueda = new javax.swing.JTextField();
        btnMEdidasCorporales = new javax.swing.JButton();
        btnPeso = new javax.swing.JButton();
        btnAntesDesp = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("TratamientoCosmotologico"); // NOI18N
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nombre", "Cedula", "Cita", "Tratamiento"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 500, 90));

        btnBusqueda.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        btnBusqueda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Lupa.jpg"))); // NOI18N
        btnBusqueda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBusquedaMouseClicked(evt);
            }
        });
        getContentPane().add(btnBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 70, 30, 30));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Cedula" }));
        getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 120, 30));
        getContentPane().add(txtBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 70, 260, 30));

        btnMEdidasCorporales.setText("Medidas Corporales");
        btnMEdidasCorporales.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnMEdidasCorporalesMouseClicked(evt);
            }
        });
        getContentPane().add(btnMEdidasCorporales, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, -1, -1));

        btnPeso.setText("Peso");
        btnPeso.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnPesoMouseClicked(evt);
            }
        });
        getContentPane().add(btnPeso, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 270, -1, -1));

        btnAntesDesp.setText("Foto Corporal");
        btnAntesDesp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAntesDespMouseClicked(evt);
            }
        });
        getContentPane().add(btnAntesDesp, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 270, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/574.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 560, 320));

        jMenuBar1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Report_1.png"))); // NOI18N
        jMenu1.setText("Historial Nutricional");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Economic.png"))); // NOI18N
        jMenu2.setText("Ficha Economica");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        jMenu5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Back.png"))); // NOI18N
        jMenu5.setText("Regresar");
        jMenu5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu5MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenu5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu5MouseClicked
        // TODO add your handling code here:
        if(Interfaz.tipousu.equalsIgnoreCase("Administrador")){
            MenuAdministrativo to = new MenuAdministrativo();
            to.setVisible(true);
            this.setVisible(false);
        } else if (Interfaz.tipousu.equalsIgnoreCase("Empleado")) {
             MenuEmpleado to = new MenuEmpleado();
            to.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_jMenu5MouseClicked

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        // TODO add your handling code here:
        HistorialNutricional obj = new HistorialNutricional();
        obj.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenu1MouseClicked

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        // TODO add your handling code here:
        FichaNutricional obj = new FichaNutricional();
        obj.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenu2MouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // CARGAMOS TABLA
        Conexion.Conectar();
        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        try {
            //dtm.addColumn("Cédula");
            dtm.addColumn("Apellido");
            dtm.addColumn("Nombre");
            dtm.addColumn("Tratamiento");
            dtm.addColumn("Atendido por:");
            //rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.CEDULA, P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT, USUARIO U  WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CED_EMPLEADO = U.CED_EMPLEADO");
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT, USUARIO U  WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CED_EMPLEADO = U.CED_EMPLEADO");
                while (rs.next()) {
                    dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)});
                }
            jTable1.setModel(dtm);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_formWindowOpened

    private void btnBusquedaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBusquedaMouseClicked
        // TODO add your handling code here:
        DefaultTableModel dtm = new DefaultTableModel();
        ResultSet rs;
        cedulaFicha = txtBusqueda.getText();
        try {
            //dtm.addColumn("Cédula");
            dtm.addColumn("Apellido");
            dtm.addColumn("Nombre");
            dtm.addColumn("Tratamiento");
            dtm.addColumn("Atendido por:");
            //rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.CEDULA, P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT, USUARIO U  WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CED_EMPLEADO = U.CED_EMPLEADO");
            rs = ventanas.Conexion.link.createStatement().executeQuery("SELECT P.APE_PAC, P.NOM_PAC, TT.NOM_TRATA, U.NOM_USUARIO FROM PACIENTE P, PACIENTE_TRATAMIENTO PT, TIPO_TRATAMIENTO TT, USUARIO U  WHERE P.CEDULA = PT.CEDULA AND PT.COD_TRATAMIENTO = TT.COD_TRATAMIENTO AND TT.COD_TRATA_FACIAL = 1 AND PT.CED_EMPLEADO = U.CED_EMPLEADO AND PT.CEDULA = '" + txtBusqueda.getText() +"'");
                while (rs.next()) {
                    dtm.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)});
                }
            jTable1.setModel(dtm);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_btnBusquedaMouseClicked

    private void btnMEdidasCorporalesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnMEdidasCorporalesMouseClicked
        // TODO add your handling code here:
        MedidasCorporales to = new MedidasCorporales();
        to.setVisible(true);
    }//GEN-LAST:event_btnMEdidasCorporalesMouseClicked

    private void btnPesoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnPesoMouseClicked
        // TODO add your handling code here:
        RegistrosPeso to = new RegistrosPeso();
        to.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnPesoMouseClicked

    private void btnAntesDespMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAntesDespMouseClicked
        // TODO add your handling code here:
        FotoCorporal to = new FotoCorporal();
        to.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnAntesDespMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TratamientoNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TratamientoNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TratamientoNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TratamientoNutricional.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TratamientoNutricional().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAntesDesp;
    private javax.swing.JButton btnBusqueda;
    private javax.swing.JButton btnMEdidasCorporales;
    private javax.swing.JButton btnPeso;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField txtBusqueda;
    // End of variables declaration//GEN-END:variables
}
